﻿function GetMailId() {
    var token = document.getElementById('TextAccessToken').value;
    var result = g_UserService.GetEmailID(token);
    if (result != null && result == true) {
        //$('#TextEMailID').val(result[0].Email_ID);
        //$('#TextFirstName').val(result[0].First_Name);
        //$('#TextLastName').val(result[0].Last_Name);

        document.getElementById('getAccessDetails').style.display = "none";
        $('#TextAccessToken').prop('readonly', true);
        showDetails();
    }
    else {
        alert("Invalid access code");
        hideDetails();
    }
}

function hideDetails() {
    document.getElementById('regDetails').style.display = 'none';
    document.getElementById('UserRegButton').style.display = 'none';

    document.getElementById('regMsg').style.display = 'none';

    document.getElementById('activate').style.display = "none";
    document.getElementById('firstTime').style.display = "block";
    document.getElementById('firstTimeContent').style.display = "block";
}

function showDetails() {
    document.getElementById('regDetails').style.display = 'block';
    document.getElementById('UserRegButton').style.display = 'block';

    document.getElementById('regMsg').style.display = 'block';

    document.getElementById('activate').style.display = "block";
    document.getElementById('firstTime').style.display = "none";
    document.getElementById('firstTimeContent').style.display = "none";
}

function CheckMailAndCode() {
    var code = $('#TextAccessToken').val();
    var mail = $('#TextEMailID').val();

    var result = g_UserService.CheckMailAndCode(code, mail);
    if (result != null && result[0].Column1 == 0) {
        return true;
    }
    else {
        document.getElementById('registerMessage').style.display = "block";
        return false;
    }
}