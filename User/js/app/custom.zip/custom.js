﻿
var g_UserService = new UserService();

function GetEmailID() {
    var token = document.getElementById('TextAccessToken').value;
    var result = g_UserService.GetEmailID(token);
    if (result != null && result == true) {
        //$('#TextEMailID').val(result[0].Email_ID);
        //$('#TextFirstName').val(result[0].First_Name);
        //$('#TextLastName').val(result[0].Last_Name);

        document.getElementById('getDetails').style.display = "none";
        $('#TextAccessToken').prop('readonly', true);
        ShowRegDetails();
    }
    else {
        alert("Invalid access code");
        HideRegDetails();
    }
}

function GetEmailIDIE() {
    var token = document.getElementById('TextAccessTokenIE').value;
    var result = g_UserService.GetEmailID(token);
    if (result != null && result == true) {
        //$('#TextEMailIDIE').val(result[0].Email_ID);
        //$('#TextFirstNameIE').val(result[0].First_Name);
        //$('#TextLastNameIE').val(result[0].Last_Name);

        $('#TextAccessTokenIE').prop('readonly', true);

        document.getElementById('accessToken').style.display = "none";
        document.getElementById('registerDetails').style.display = "block";
        document.getElementById('activate').style.display = "block";
        document.getElementById('regMsg').style.display = "block";
        document.getElementById('getAccessDetails').style.display = "none";
        document.getElementById('redirect').style.display = "none";
    }
    else {
        alert("Invalid access code");
        document.getElementById('accessToken').style.display = "block";
        document.getElementById('registerDetails').style.display = "none";
        document.getElementById('activate').style.display = "none";
        document.getElementById('regMsg').style.display = "none";
        document.getElementById('getAccessDetails').style.display = "block";
        document.getElementById('redirect').style.display = "block";
    }
}

function HideRegDetails() {
    document.getElementById('regDetails').style.display = 'none';

    document.getElementById('loginMsg').style.display = "none";
    document.getElementById('accessContent').style.display = 'block';
    document.getElementById('registerContent').style.display = 'none';
}

function ShowRegDetails() {
    document.getElementById('regDetails').style.display = 'block';

    document.getElementById('accessContent').style.display = 'none';
    document.getElementById('registerContent').style.display = 'block';
    document.getElementById('modalTitle').innerHTML = "Activate your account";
}

function LoadPlayer() {
    var isiDevice = /ipad|iphone|ipod/i.test(navigator.userAgent.toLowerCase());

    if (isiDevice) {
       //alert("iPad")
    }

    var isAndroid = /android/i.test(navigator.userAgent.toLowerCase());

    if (isAndroid) {
        //alert("Android");
    }

    var isBlackBerry = /blackberry/i.test(navigator.userAgent.toLowerCase());

    if (isBlackBerry) {
       //alert("BlackBerry");
    }

    var isWindows = /windows/i.test(navigator.userAgent.toLowerCase());

    if (isWindows) {
        //alert("Windows");
    }
}

function ShowPlayer(url) {
	var params = 'width=' + screen.width;
	params += ', height=' + screen.height;
	params += ', top=0, left=0'
	params += ', status=no'
	params += ', fullscreen=yes'
	params += ', resizable=no';

    window.open(url, "newWindow", params);
}

function ShowHome() {
    document.getElementById('homeTabs').style.display = "block";
    document.getElementById('BackButton').style.display = "none";
    document.getElementById('newUpdates').style.display = "none";

    // Set Text
    document.getElementById("welcome").style.display = "block"
    document.getElementById("titles").style.display = "none"
    document.getElementById("texts").style.display = "none"
}

function ShowUpdates() {
    document.getElementById('homeTabs').style.display = "none";
    document.getElementById('BackButton').style.display = "block";
    document.getElementById('newUpdates').style.display = "block";

    // Set Text
    document.getElementById("welcome").style.display = "none"
    document.getElementById("titles").style.display = "block"
    document.getElementById("texts").style.display = "block"
}

function AuthenticateUser() {

    var username;
    var password;
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf('MSIE ');
    var trident = ua.indexOf('Trident/');

    if (msie > 0) { // IE 10 and 9
        username = document.getElementById('LoginIEUsername').value;
        password = document.getElementById('LoginIEPassword').value;
    }

    if (trident > 0) { // IE 11
        username = document.getElementById('LoginIEUsername').value;
        password = document.getElementById('LoginIEPassword').value;
    }

    else { // Other browsers
        username = document.getElementById('LoginUsername').value;
        password = document.getElementById('LoginPassword').value;
    }
    

    var result = g_UserService.AuthenticateUser(username, password);

    if (parseInt(result.UserID) > 0) {
        return true;
    }
    else {
        document.getElementById('loginMsg').style.display = "block";
        document.getElementById('InvalidMsg').style.display = "block";       
        return false;
    }
}

function IsUsernameExist(field, rules, i, options) {
    var result = g_UserService.IsUsernameExist(field.val());
    if (result) {
        return "Username already taken by someone";
    }
}

function PopulateStatesOfCountry(countryId) {
    var id = document.getElementById('DDRegion');
    id.options.length = 0;
    regionList = g_UserService.GetStatesOfCountry(parseInt(countryId));
    for (var i = 0; i < regionList.length; i++) {
        var opt = document.createElement('option');
        opt.innerHTML = regionList[i].State;
        opt.value = regionList[i].State_Id;
        id.appendChild(opt);
    }
}

function PopulateCityOfStates(stateId) {
    var id = document.getElementById('DDCity');
    id.options.length = 0;
    cityList = g_UserService.GetCityofState(parseInt(stateId));
    for (var i = 0; i < cityList.length; i++) {
        var opt = document.createElement('option');
        opt.innerHTML = cityList[i].City;
        opt.value = cityList[i].City_Id;
        id.appendChild(opt);
    }
}

function PopulateStatesOfCountryIE(countryId) {
    var id = document.getElementById('DDRegionIE');
    id.options.length = 0;
    regionList = g_UserService.GetStatesOfCountry(parseInt(countryId));
    for (var i = 0; i < regionList.length; i++) {
        var opt = document.createElement('option');
        opt.innerHTML = regionList[i].State;
        opt.value = regionList[i].State_Id;
        id.appendChild(opt);
    }
}

function PopulateCityOfStatesIE(stateId) {
    var id = document.getElementById('DDCityIE');
    id.options.length = 0;
    cityList = g_UserService.GetCityofState(parseInt(stateId));
    for (var i = 0; i < cityList.length; i++) {
        var opt = document.createElement('option');
        opt.innerHTML = cityList[i].City;
        opt.value = cityList[i].City_Id;
        id.appendChild(opt);
    }
}

function preLoadImages() {
    loadImages(
        'img/menu/menu0001.jpg',
        'img/menu/menu0002.jpg',
        'img/menu/menu0003.jpg',
        'img/menu/menu0004.jpg',
        'img/menu/menu0005.jpg',
        'img/menu/menu0006.jpg',
        'img/menu/menu0007.jpg',
        'img/menu/menu0008.jpg',
        'img/menu/menu0009.jpg',
        'img/menu/menu0010.jpg',
        'img/menu/menu0011.jpg',
        'img/menu/menu0012.jpg',
        'img/menu/menu0013.jpg',
        'img/menu/menu0014.jpg',
        'img/menu/menu0014.jpg',
        'img/welcome/ADCetris_Welcome_00000.jpg',
        'img/welcome/ADCetris_Welcome_00001.jpg',
        'img/welcome/ADCetris_Welcome_00002.jpg',
        'img/welcome/ADCetris_Welcome_00003.jpg',
        'img/welcome/ADCetris_Welcome_00004.jpg',
        'img/welcome/ADCetris_Welcome_00005.jpg',
        'img/welcome/ADCetris_Welcome_00006.jpg',
        'img/welcome/ADCetris_Welcome_00007.jpg',
        'img/welcome/ADCetris_Welcome_00008.jpg',
        'img/welcome/ADCetris_Welcome_00009.jpg',
        'img/welcome/ADCetris_Welcome_00010.jpg',
        'img/welcome/ADCetris_Welcome_00011.jpg',
        'img/welcome/ADCetris_Welcome_00012.jpg',
        'img/welcome/ADCetris_Welcome_00013.jpg',
        'img/welcome/ADCetris_Welcome_00014.jpg',
        'img/accesscode/ADCetris_AccessCode_00000.jpg',
        'img/accesscode/ADCetris_AccessCode_00001.jpg',
        'img/accesscode/ADCetris_AccessCode_00002.jpg',
        'img/accesscode/ADCetris_AccessCode_00003.jpg',
        'img/accesscode/ADCetris_AccessCode_00004.jpg',
        'img/accesscode/ADCetris_AccessCode_00005.jpg',
        'img/accesscode/ADCetris_AccessCode_00006.jpg',
        'img/accesscode/ADCetris_AccessCode_00007.jpg',
        'img/accesscode/ADCetris_AccessCode_00008.jpg',
        'img/accesscode/ADCetris_AccessCode_00009.jpg',
        'img/accesscode/ADCetris_AccessCode_00010.jpg',
        'img/accesscode/ADCetris_AccessCode_00011.jpg',
        'img/accesscode/ADCetris_AccessCode_00012.jpg',
        'img/accesscode/ADCetris_AccessCode_00013.jpg',
        'img/accesscode/ADCetris_AccessCode_00014.jpg',
        'img/signin/ADCetris_SignIn_00000.jpg',
        'img/signin/ADCetris_SignIn_00001.jpg',
        'img/signin/ADCetris_SignIn_00002.jpg',
        'img/signin/ADCetris_SignIn_00003.jpg',
        'img/signin/ADCetris_SignIn_00004.jpg',
        'img/signin/ADCetris_SignIn_00005.jpg',
        'img/signin/ADCetris_SignIn_00006.jpg',
        'img/signin/ADCetris_SignIn_00007.jpg',
        'img/signin/ADCetris_SignIn_00008.jpg',
        'img/signin/ADCetris_SignIn_00009.jpg',
        'img/signin/ADCetris_SignIn_00010.jpg',
        'img/signin/ADCetris_SignIn_00011.jpg',
        'img/signin/ADCetris_SignIn_00012.jpg',
        'img/signin/ADCetris_SignIn_00013.jpg',
        'img/signin/ADCetris_SignIn_00014.jpg',
        'img/support/ADCetris_TechSupport_00000.jpg',
        'img/support/ADCetris_TechSupport_00001.jpg',
        'img/support/ADCetris_TechSupport_00002.jpg',
        'img/support/ADCetris_TechSupport_00003.jpg',
        'img/support/ADCetris_TechSupport_00004.jpg',
        'img/support/ADCetris_TechSupport_00005.jpg',
        'img/support/ADCetris_TechSupport_00006.jpg',
        'img/support/ADCetris_TechSupport_00007.jpg',
        'img/support/ADCetris_TechSupport_00008.jpg',
        'img/support/ADCetris_TechSupport_00009.jpg',
        'img/support/ADCetris_TechSupport_00010.jpg',
        'img/support/ADCetris_TechSupport_00011.jpg',
        'img/support/ADCetris_TechSupport_00012.jpg',
        'img/support/ADCetris_TechSupport_00013.jpg',
        'img/support/ADCetris_TechSupport_00014.jpg'
        );
}

function loadImages(){
    var images = new Array()
    for (var i = 0; i < loadImages.arguments.length; i++) {
        images[i] = new Image();
        images[i].src = loadImages.arguments[i];
    }
}




preLoadImages();

function Loading() {
    document.getElementById('loading').style.display = 'block';
    HideRegDetails();
    animateMenu();
    document.getElementById('loading').style.display = 'none';
    document.getElementById('screen').style.display = 'block';
}


// World DB

function InsertCountries() {
    var country = document.getElementById('country');
    for (var i = 0; i < country.length; i++) {
        g_UserService.InsertCountries(country.options[i].value, country.options[i].text);
    }
    alert("All were inserted")
}

function InsertStates() {
    var province = document.getElementById('province');
    var e = document.getElementById('country');
    var country = e.options[e.selectedIndex].value;
    for (var i = 0; i < province.length; i++) {
        g_UserService.InsertStates(province.options[i].value, country, province.options[i].text);
    }
    alert("All were inserted");
}

function InsertCities() {
    var city = document.getElementById('region');
    var c = document.getElementById('country');
    var p = document.getElementById('province');

    var country = c.options[c.selectedIndex].value;
    var province = p.options[p.selectedIndex].value;

    for (var i = 0; i < city.length; i++) {
        g_UserService.InsertCities(city.options[i].value, city.options[i].text, province, country);
    }
    alert("All were inserted");
}

function ShowRegIE() {
    document.getElementById('forIELogin').style.display = "none";
    document.getElementById('forIEReg').style.display = "block";
    document.getElementById('forIEPwd').style.display = "none";
    document.getElementById('forIETech').style.display = "none";
}

function ShowSupportIE() {
    document.getElementById('forIELogin').style.display = "none";
    document.getElementById('forIEReg').style.display = "none";
    document.getElementById('forIEPwd').style.display = "none";
    document.getElementById('forIETech').style.display = "block";

}
function ForgotPassword() {
    document.getElementById('forIELogin').style.display = "none";
    document.getElementById('forIEReg').style.display = "none";
    document.getElementById('forIEPwd').style.display = "block";
    document.getElementById('forIETech').style.display = "none";
}

function CheckMailAndCode() {
    var code = $('#TextAccessToken').val();
    var mail = $('#TextEMailID').val();

    var result = g_UserService.CheckMailAndCode(code, mail);
    if (result != null && result[0].Column1 == 0) {
        return true;
    }
    else {
        document.getElementById('registerMessage').style.display = "block";
        return false;
    }
}

function CheckMailAndCodeIE() {
    var code = $('#TextAccessTokenIE').val();
    var mail = $('#TextEMailIDIE').val();

    var result = g_UserService.CheckMailAndCode(code, mail);
    if (result != null && result[0].Column1 == 0) {
        return true;
    }
    else {
        document.getElementById('registerMessageIE').style.display = "block";
        return false;
    }
}

function ShowWelcomeMsgIE() {
    $('#welcome-form').modal('show');
}

// Check Email Entry

function IsEmailExist(reqFrom) {

    var mail;
    if (reqFrom == "IE") {
        mail = $('#TextFpwd').val();
    }
    else {
        mail = $('#TextEmail').val();
    }

    var result = g_UserService.IsEmailExist(mail);
    if (result) {
        return true;
    }
    else {
        if (reqFrom == "IE") {
            document.getElementById('notExistIE').style.display = "block";
            document.getElementById('notExistIE').innerHTML = "Mail Id doesn't exist";
        }
        else {
            document.getElementById('notExist').style.display = "block";
            document.getElementById('notExist').innerHTML = "Mail Id doesn't exist";
        }
        return false;
    }
}
